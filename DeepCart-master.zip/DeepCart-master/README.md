# DeepCart
This is the hard work of Deep and contributing this code for free for learning purpose.
No has copy rights on this except code owner.

I would request you to please subscribe , like and comment on my channel.
The way I am hellping you ,please help me as well.


Here are the video tutorials of this comeplete series.

Lesson-1
https://youtu.be/JjVyvy3ctFE

Lesson-2
https://youtu.be/SrmShkVhKhU

Lesson-3
https://youtu.be/wWknX6eaWjg

Lesson-4
https://youtu.be/CLqoEHt2aNk

Lesson-5
https://youtu.be/orRQrwPpbac

Lesson-6
https://youtu.be/qbGdKW-RWw0

Lesson-7
https://youtu.be/HeYsF01c5iw

Lesson-8
https://youtu.be/Oylx-hpaUDc

Please , please subscribe my channel.Comment your views about my channel and social work of giving the source code.


This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.0.0.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
# DeepCart
