export interface Registration
{
    Id:number;
    UserName:string;
    Password:string;
    Email:string;
    Role:string;
    Gender:string;
    Phone:string;
}