export interface OrderItem
{
         ID :number
         ProductID:number
         SellerID :number
         ProductName :string
         OrderedQuantity :number
         PerUnitPrice :number
         OrderID :number
}